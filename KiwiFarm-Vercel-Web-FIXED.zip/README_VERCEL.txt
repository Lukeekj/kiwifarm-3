KiwiFarm Web - Vercel

Como subir:

1. Use o ZIP KiwiFarm-Vercel-Web-FIXED.zip.
2. No Vercel, crie Project > Import.
3. Framework preset: Other.
4. Build command: deixe vazio.
5. Output directory: deixe vazio.
6. Root directory: a raiz onde estao index.html, vercel.json e api/.
7. O Vercel usara vercel.json com rewrites e as funcoes Python em /api.

Se aparecer 404:

- Confirme que index.html ficou na raiz do deploy.
- Confirme que vercel.json ficou na raiz do deploy.
- Nao suba uma pasta acima que contenha KiwiFarm-Vercel-Web dentro; suba o conteudo da pasta.
- Use o ZIP FIXED, porque ele foi gerado com separadores / compativeis com deploy Linux.

URL local de API:

- /api/health
- /api/call

Importante:

Vercel Serverless nao e ideal para banco JSON persistente. Este pacote roda com banco em /tmp durante a execucao. Para producao real, troque para Postgres/Supabase.

O dominio https://kiwifarm.mobile deve ser adicionado em Project Settings > Domains no Vercel e apontado no DNS conforme o Vercel mostrar.
