import json
import traceback
from http.server import BaseHTTPRequestHandler

from api._kiwifarm_loader import load_api


ALLOWED_METHODS = {
    "bootstrap",
    "login",
    "register",
    "dashboard",
    "kiwify_login",
    "run_factory",
    "open_products_folder",
    "generate_keys",
    "search_keys",
    "update_key_status",
    "redeem_key",
    "save_settings",
    "search_users",
    "set_user_access",
    "expire_user",
    "save_plan",
    "create_payment_request",
    "mark_paid",
    "review_payment",
    "send_dm",
    "mark_thread_read",
    "apply_reseller",
    "apply_promoter",
    "reseller_buy_credits",
    "reseller_generate_key",
    "social_login",
    "connect_social",
}


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length") or "0")
            payload = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
            method_name = str(payload.get("method") or "")
            args = payload.get("args") or []
            kwargs = payload.get("kwargs") or {}
            if method_name not in ALLOWED_METHODS:
                return self.respond({"ok": False, "message": "Metodo nao permitido."}, 403)
            api = load_api()
            method = getattr(api, method_name, None)
            if not method:
                return self.respond({"ok": False, "message": "Metodo nao encontrado."}, 404)
            return self.respond(method(*args, **kwargs))
        except Exception as exc:
            traceback.print_exc()
            return self.respond({"ok": False, "message": str(exc)}, 500)

    def respond(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
