import http from "http";
import { spawn } from "child_process";
import { createHash, randomUUID } from "crypto";
import { mkdirSync, openSync, readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const port = Number(process.env.KIWIFARM_BRIDGE_PORT || 4317);
const logDir = path.join(root, "logs");
const allowedOrigins = new Set([
  "http://127.0.0.1:3000",
  "http://localhost:3000",
  "http://127.0.0.1:4173",
  "http://localhost:4173",
  "null",
  ...(process.env.KIWIFARM_ALLOWED_ORIGINS || "").split(",").map((item) => item.trim()).filter(Boolean)
]);

mkdirSync(logDir, { recursive: true });

const server = http.createServer(async (request, response) => {
  const origin = request.headers.origin || "null";

  if (!isOriginAllowed(origin)) {
    response.writeHead(403, { "content-type": "application/json" });
    response.end(JSON.stringify({ message: "Origem nao autorizada pelo KiwiFarm Bridge." }));
    return;
  }

  setCors(response, origin);

  if (request.method === "OPTIONS") {
    response.writeHead(204);
    response.end();
    return;
  }

  if (request.url === "/health" && request.method === "GET") {
    sendJson(response, 200, {
      ok: true,
      bridge: "kiwifarm-local-bridge",
      port,
      session: ".sessions/kiwify-chrome"
    });
    return;
  }

  if (request.url === "/logs" && request.method === "GET") {
    const logPath = path.join(logDir, "kiwify-autopilot.log");
    const text = safeRead(logPath);
    sendJson(response, 200, { log: text.slice(-12000) });
    return;
  }

  if (request.url === "/kiwify/login" && request.method === "POST") {
    const job = startAutopilot(["--login"]);
    sendJson(response, 200, {
      status: "started",
      job,
      message: "Chrome abrindo para login inicial da Kiwify."
    });
    return;
  }

  if (request.url === "/kiwify/run" && request.method === "POST") {
    const body = await readJson(request);
    const niche = typeof body.niche === "string" && body.niche.trim() ? body.niche.trim() : "produtividade com inteligencia artificial";
    const ownerId = typeof body.ownerId === "string" && body.ownerId.trim() ? body.ownerId.trim() : "admin-primary";
    const job = startAutopilot(["--run", `--niche=${niche}`, `--owner-id=${ownerId}`]);

    sendJson(response, 200, {
      status: "started",
      job,
      message: "KiwiFarm esta gerando ebook, capa, oferta e abrindo a Kiwify no Chrome."
    });
    return;
  }

  sendJson(response, 404, { message: "Rota nao encontrada." });
});

server.listen(port, "127.0.0.1", () => {
  console.log(`KiwiFarm Bridge online em http://127.0.0.1:${port}`);
});

function startAutopilot(args) {
  const jobId = randomUUID();
  const logFile = openSync(path.join(logDir, "kiwify-autopilot.log"), "a");
  const child = spawn(process.execPath, [path.join(root, "scripts", "kiwifarm-autopilot.mjs"), ...args], {
    cwd: root,
    detached: true,
    stdio: ["ignore", logFile, logFile],
    windowsHide: false
  });
  child.unref();
  return {
    id: jobId,
    pid: child.pid,
    fingerprint: createHash("sha1").update(`${jobId}:${Date.now()}`).digest("hex").slice(0, 10)
  };
}

function isOriginAllowed(origin) {
  return allowedOrigins.has(origin);
}

function setCors(response, origin) {
  response.setHeader("access-control-allow-origin", origin);
  response.setHeader("access-control-allow-methods", "GET,POST,OPTIONS");
  response.setHeader("access-control-allow-headers", "content-type,authorization");
}

function sendJson(response, status, payload) {
  response.writeHead(status, { "content-type": "application/json" });
  response.end(JSON.stringify(payload));
}

function readJson(request) {
  return new Promise((resolve) => {
    let raw = "";
    request.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 1024 * 128) request.destroy();
    });
    request.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        resolve({});
      }
    });
  });
}

function safeRead(filePath) {
  try {
    return readFileSync(filePath, "utf8");
  } catch {
    return "";
  }
}
