import hashlib
import base64
import json
import os
import secrets
import string
import subprocess
import sys
import time
from urllib.parse import unquote, urlparse
from io import BytesIO
from datetime import datetime, timedelta, timezone
from pathlib import Path

import qrcode
import webview


ADMIN_USERS = [
    {
        "id": "admin-primary",
        "email": "luisfelipegarciarodrigues864@gmail.com",
        "username": "luisadmin",
        "name": "Luis Felipe",
        "role": "admin",
        "roles": ["admin"],
        "passwordHash": "81c2ebb277b0b8a4c12ab4f212372f8e76c90ed96b244a1b68829768dde7fe7c",
        "createdAt": "2026-06-15T00:00:00.000Z",
        "trialEndsAt": None,
        "accessEndsAt": None,
    },
    {
        "id": "admin-secondary",
        "email": "luisfelipe@kiwifarm.local",
        "username": "luisfelipe",
        "name": "Luis Felipe",
        "role": "admin",
        "roles": ["admin"],
        "passwordHash": "890a35a7ec957b685c97b0f5912c1c06cfcd5eb8e1df2eca2b6e72438a36dc1e",
        "createdAt": "2026-06-15T00:00:00.000Z",
        "trialEndsAt": None,
        "accessEndsAt": None,
    },
]

DEFAULT_PLANS = [
    {
        "id": "starter",
        "name": "Mensal Basic",
        "priceCents": 1990,
        "durationDays": 30,
        "active": True,
        "stockTarget": 25,
        "keyCostCredits": 2,
        "quotas": {"dailyProducts": 2, "dailyVideos": 3},
        "resellerEnabled": True,
    },
    {
        "id": "pro",
        "name": "Mensal Pro",
        "priceCents": 4990,
        "durationDays": 30,
        "active": True,
        "stockTarget": 50,
        "keyCostCredits": 3,
        "quotas": {"dailyProducts": 5, "dailyVideos": 8},
        "resellerEnabled": True,
    },
    {
        "id": "permanent-basic",
        "name": "Permanente Basic",
        "priceCents": 9990,
        "durationDays": 3650,
        "active": True,
        "stockTarget": 15,
        "keyCostCredits": 5,
        "quotas": {"dailyProducts": 2, "dailyVideos": 3},
        "resellerEnabled": True,
    },
]

DEFAULT_SETTINGS = {
    "pixKey": "configure-sua-chave-pix-no-admin",
    "supportWhatsapp": "configure seu WhatsApp no admin",
    "creditPriceCents": 1000,
    "minCreditPurchase": 5,
    "defaultCommissionPercent": 40,
    "siteInviteBase": "https://kiwifarm.mobile",
    "kiwifyProductSiteUrl": "",
}

DEFAULT_PERMISSIONS = {
    "admin": {
        "factory": True,
        "redeemKey": True,
        "buyPlans": True,
        "resellerArea": True,
        "promoterArea": True,
        "adminPanel": True,
    },
    "free": {
        "factory": True,
        "redeemKey": True,
        "buyPlans": True,
        "resellerArea": False,
        "promoterArea": False,
        "adminPanel": False,
    },
    "monthly": {
        "factory": True,
        "redeemKey": True,
        "buyPlans": True,
        "resellerArea": False,
        "promoterArea": False,
        "adminPanel": False,
    },
    "permanent": {
        "factory": True,
        "redeemKey": True,
        "buyPlans": True,
        "resellerArea": False,
        "promoterArea": False,
        "adminPanel": False,
    },
    "reseller": {
        "factory": True,
        "redeemKey": True,
        "buyPlans": True,
        "resellerArea": True,
        "promoterArea": False,
        "adminPanel": False,
    },
    "promoter": {
        "factory": True,
        "redeemKey": True,
        "buyPlans": True,
        "resellerArea": False,
        "promoterArea": True,
        "adminPanel": False,
    },
}

ROLE_LABELS = {
    "admin": "Admin",
    "free": "Membro gratis",
    "monthly": "Membro mensal",
    "permanent": "Membro permanente",
    "reseller": "Revendedor",
    "pending_reseller": "Revendedor pendente",
    "promoter": "Divulgador",
}


def base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


BASE = base_dir()
APP_HTML = BASE / "app" / "index.html"
DATA = BASE / "data"
DB_PATH = DATA / "kiwifarm-webview-db.json"
LEGACY_DB_PATH = DATA / "kiwifarm-db.json"
LOG_DIR = BASE / "logs"
LOG_PATH = LOG_DIR / "kiwifarm.log"
PRODUCTS_DIR = BASE / "generated-products"
SESSION_DIR = BASE / ".sessions" / "kiwify-chrome"
SOCIAL_SESSION_DIR = BASE / ".sessions" / "social"


def now() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime | None) -> str | None:
    return dt.isoformat().replace("+00:00", "Z") if dt else None


def parse_iso(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def sha(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def new_id(prefix: str) -> str:
    return f"{prefix}-{int(time.time() * 1000)}-{secrets.token_hex(3)}"


def ensure_dirs():
    DATA.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    PRODUCTS_DIR.mkdir(parents=True, exist_ok=True)
    SESSION_DIR.mkdir(parents=True, exist_ok=True)
    SOCIAL_SESSION_DIR.mkdir(parents=True, exist_ok=True)


def log(text):
    ensure_dirs()
    with LOG_PATH.open("a", encoding="utf-8") as handle:
        handle.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {text}\n")


def read_db():
    ensure_dirs()
    if DB_PATH.exists():
        db = json.loads(DB_PATH.read_text(encoding="utf-8-sig"))
    elif LEGACY_DB_PATH.exists():
        db = json.loads(LEGACY_DB_PATH.read_text(encoding="utf-8-sig"))
    else:
        db = {}
    changed = ensure_schema(db)
    if changed or not DB_PATH.exists():
        write_db(db)
    return db


def write_db(db):
    ensure_dirs()
    DB_PATH.write_text(json.dumps(db, indent=2, ensure_ascii=True), encoding="utf-8")


def ensure_schema(db):
    changed = False
    for key, default in {
        "users": [],
        "products": [],
        "plans": DEFAULT_PLANS,
        "keys": [],
        "payments": [],
        "messages": [],
        "applications": [],
        "settings": DEFAULT_SETTINGS,
        "permissions": DEFAULT_PERMISSIONS,
        "roleLabels": {},
        "socialConnections": [],
        "commissions": [],
    }.items():
        if key not in db or db[key] in (None, ""):
            db[key] = json.loads(json.dumps(default))
            changed = True

    db["settings"] = {**DEFAULT_SETTINGS, **db.get("settings", {})}
    clean_invite_base = normalize_public_base(db["settings"].get("siteInviteBase"))
    if db["settings"].get("siteInviteBase") != clean_invite_base:
        db["settings"]["siteInviteBase"] = clean_invite_base
        changed = True
    clean_kiwify_url = normalize_public_base(db["settings"].get("kiwifyProductSiteUrl"))
    if db["settings"].get("kiwifyProductSiteUrl") != clean_kiwify_url:
        db["settings"]["kiwifyProductSiteUrl"] = clean_kiwify_url
        changed = True
    for role, perms in DEFAULT_PERMISSIONS.items():
        db["permissions"].setdefault(role, {})
        db["permissions"][role] = {**perms, **db["permissions"].get(role, {})}

    existing_ids = {user.get("id") for user in db["users"]}
    for admin in ADMIN_USERS:
        if admin["id"] not in existing_ids:
            db["users"].insert(0, dict(admin))
            changed = True

    for user in db["users"]:
        role = user.get("role") or "free"
        if role == "user":
            role = "free"
            user["role"] = role
            changed = True
        roles = user.get("roles") or [role]
        if role == "admin" and "admin" not in roles:
            roles.append("admin")
        if "profile" not in user:
            user["profile"] = {"photo": "", "bio": "", "social": {}}
            changed = True
        if "credits" not in user:
            user["credits"] = 0
            changed = True
        if "roles" not in user or user["roles"] != roles:
            user["roles"] = roles
            changed = True
        if "inviteCode" not in user:
            user["inviteCode"] = invite_code(user)
            changed = True
        if has_role(user, "reseller") and not user.get("resellerInviteCode"):
            user["resellerInviteCode"] = f"rev-{strip_invite_prefix(user['inviteCode'])}"
            changed = True
        if has_role(user, "promoter") and not user.get("promoterInviteCode"):
            user["promoterInviteCode"] = f"div-{strip_invite_prefix(user['inviteCode'])}"
            changed = True

    db["plans"] = [normalize_plan(plan) for plan in db["plans"]]
    return changed


def normalize_plan(plan):
    fallback = next((p for p in DEFAULT_PLANS if p["id"] == plan.get("id")), DEFAULT_PLANS[0])
    clean = {**fallback, **plan}
    clean["priceCents"] = int(float(clean.get("priceCents") or 0))
    clean["durationDays"] = int(float(clean.get("durationDays") or 1))
    clean["stockTarget"] = int(float(clean.get("stockTarget") or 0))
    clean["keyCostCredits"] = int(float(clean.get("keyCostCredits") or 1))
    clean["active"] = bool(clean.get("active", True))
    clean["resellerEnabled"] = bool(clean.get("resellerEnabled", True))
    clean["grantRoles"] = clean.get("grantRoles") or []
    quotas = clean.get("quotas") or {}
    clean["quotas"] = {
        "dailyProducts": int(float(quotas.get("dailyProducts") or 0)),
        "dailyVideos": int(float(quotas.get("dailyVideos") or 0)),
    }
    return clean


def invite_code(user):
    base = (user.get("username") or user.get("name") or user.get("email") or "kiwi").lower()
    compact = "".join(char for char in base if char.isalnum())[:12] or "kiwi"
    return f"{compact}-{secrets.token_hex(2)}"


def strip_invite_prefix(value):
    clean = str(value or "").strip()
    for prefix in ("rev-", "div-"):
        if clean.lower().startswith(prefix):
            return clean[len(prefix):]
    return clean


def is_admin(user):
    return user and ("admin" in user.get("roles", []) or user.get("role") == "admin")


def has_role(user, role):
    return role in (user.get("roles") or [])


def add_role(user, role):
    roles = user.setdefault("roles", [])
    if role not in roles:
        roles.append(role)
    if role in ("admin", "reseller", "promoter", "permanent", "monthly"):
        user["role"] = role


def remove_role(user, role):
    user["roles"] = [item for item in user.get("roles", []) if item != role]
    if user.get("role") == role:
        user["role"] = user["roles"][0] if user["roles"] else "free"


def access_status(user):
    if is_admin(user):
        return {"active": True, "kind": "admin", "remainingSeconds": None, "endsAt": None}
    end = parse_iso(user.get("accessEndsAt") or user.get("trialEndsAt"))
    if not end:
        return {"active": False, "kind": "expired", "remainingSeconds": 0, "endsAt": None}
    remaining = int((end - now()).total_seconds())
    kind = user.get("planStatus", "trial")
    if has_role(user, "permanent"):
        kind = "permanent"
    elif has_role(user, "monthly"):
        kind = "monthly"
    return {
        "active": remaining > 0,
        "kind": kind if remaining > 0 else "expired",
        "remainingSeconds": max(0, remaining),
        "endsAt": iso(end),
    }


def public_user(user):
    data = {k: v for k, v in user.items() if k != "passwordHash"}
    data["access"] = access_status(user)
    data["roleLabel"] = ", ".join(ROLE_LABELS.get(role, role) for role in data.get("roles", []))
    return data


def money(cents):
    return f"R$ {cents / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def find_chrome():
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        str(Path(os.environ.get("LOCALAPPDATA", "")) / "Google" / "Chrome" / "Application" / "chrome.exe"),
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    return None


def find_node():
    bundled = Path.home() / ".cache" / "codex-runtimes" / "codex-primary-runtime" / "dependencies" / "node" / "bin" / "node.exe"
    if bundled.exists():
        return str(bundled)
    return "node"


def open_chrome_profile(profile_dir: Path, url: str, debug_port: int | None = None):
    chrome = find_chrome()
    if not chrome:
        return {"ok": False, "message": "Chrome nao encontrado."}
    profile_dir.mkdir(parents=True, exist_ok=True)
    args = [
        chrome,
        f"--user-data-dir={profile_dir}",
        "--profile-directory=Default",
        "--new-window",
        "--no-first-run",
        "--disable-first-run-ui",
        "--start-maximized",
    ]
    if debug_port:
        args.append(f"--remote-debugging-port={debug_port}")
    args.append(url)
    subprocess.Popen(args)
    return {"ok": True, "message": "Chrome aberto. Faca login uma vez e feche a janela quando terminar."}


def make_key_code(prefix="OMEGA-"):
    allowed = string.ascii_uppercase + string.digits
    chunks = ["".join(secrets.choice(allowed) for _ in range(4)) for _ in range(4)]
    return f"{prefix or ''}{'-'.join(chunks)}"


def payment_qr_data_url(text):
    image = qrcode.make(str(text or ""))
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode("ascii")


def stock_count(db, plan_id):
    return len([k for k in db["keys"] if k.get("planId") == plan_id and k.get("status") == "stock"])


class Api:
    def bootstrap(self):
        db = read_db()
        return {"plans": self.plans_with_stock(db), "stats": self.dashboard_stats(db), "settings": db["settings"]}

    def login(self, identifier, password):
        db = read_db()
        ident = str(identifier or "").strip().lower()
        hashed = sha(str(password or ""))
        user = next(
            (
                item
                for item in db["users"]
                if (item["email"].lower() == ident or item["username"].lower() == ident) and item["passwordHash"] == hashed
            ),
            None,
        )
        if not user:
            return {"ok": False, "message": "Login ou senha invalidos."}
        return {"ok": True, "user": public_user(user), "dashboard": self.dashboard_for(user)}

    def register(self, name, email, username, password, invite_code_value=""):
        db = read_db()
        email = str(email or "").strip().lower()
        username = str(username or "").strip().lower()
        name = str(name or "").strip()
        if not name or "@" not in email or len(username) < 3 or len(str(password or "")) < 8:
            return {"ok": False, "message": "Preencha nome, email, usuario e senha com pelo menos 8 caracteres."}
        if any(user["email"].lower() == email or user["username"].lower() == username for user in db["users"]):
            return {"ok": False, "message": "Email ou usuario ja cadastrado."}

        inviter = self.find_inviter(db, invite_code_value)
        trial_end = now() + timedelta(hours=5)
        user = {
            "id": new_id("user"),
            "email": email,
            "username": username,
            "name": name,
            "role": "free",
            "roles": ["free"],
            "passwordHash": sha(str(password)),
            "createdAt": iso(now()),
            "trialEndsAt": iso(trial_end),
            "accessEndsAt": iso(trial_end),
            "planStatus": "trial",
            "credits": 0,
            "inviteCode": invite_code({"username": username, "email": email, "name": name}),
            "profile": {"photo": "", "bio": "", "social": {}},
            "referredBy": inviter["id"] if inviter else None,
            "referredByRole": inviter["role"] if inviter else None,
        }
        db["users"].append(user)
        if inviter:
            self.add_message(
                db,
                from_user_id=user["id"],
                to_user_id=inviter["id"],
                text=f"{name} criou conta pelo seu convite.",
                kind="referral",
                payload={"newUserId": user["id"]},
            )
        write_db(db)
        return {"ok": True, "user": public_user(user), "dashboard": self.dashboard_for(user)}

    def dashboard(self, user_id):
        db = read_db()
        user = self.get_user(db, user_id)
        if not user:
            return {"ok": False, "message": "Usuario nao encontrado."}
        return {"ok": True, "user": public_user(user), "dashboard": self.dashboard_for(user)}

    def dashboard_for(self, user):
        db = read_db()
        products = db["products"] if is_admin(user) else [p for p in db["products"] if p.get("ownerId") == user["id"]]
        messages = self.visible_messages(db, user)
        return {
            "metrics": {
                "accounts": len(db["users"]) if is_admin(user) else 1,
                "products": len(products),
                "activeProducts": len([p for p in products if p.get("status") in ("active", "winner", "creating")]),
                "estimatedRevenueCents": sum(int(p.get("estimatedRevenueCents", 0)) for p in products),
                "pendingPayments": len([p for p in db["payments"] if p.get("status") == "waiting_owner"]),
                "keyStock": len([k for k in db["keys"] if k.get("status") == "stock"]),
                "credits": int(user.get("credits", 0)),
            },
            "products": [{**p, "owner": self.owner(db, p.get("ownerId"))} for p in products],
            "accounts": [self.account_summary(db, u) for u in db["users"]] if is_admin(user) else [],
            "plans": self.plans_with_stock(db),
            "settings": db["settings"],
            "permissions": db["permissions"],
            "roleLabels": db.get("roleLabels", {}),
            "keys": self.visible_keys(db, user),
            "payments": self.visible_payments(db, user),
            "messages": messages,
            "applications": self.visible_applications(db, user),
            "rankings": self.rankings(db) if is_admin(user) else {},
            "socialConnections": [s for s in db["socialConnections"] if is_admin(user) or s.get("userId") == user["id"]],
            "commissions": [c for c in db["commissions"] if is_admin(user) or c.get("promoterId") == user["id"]],
            "contacts": self.contacts(db, user),
        }

    def save_plan(self, plan):
        db = read_db()
        plan_id = str(plan.get("id") or "").strip() or new_id("plan")
        clean = normalize_plan(
            {
                "id": plan_id,
                "name": str(plan.get("name") or "Plano"),
                "priceCents": int(float(plan.get("priceCents") or 0)),
                "durationDays": int(float(plan.get("durationDays") or 1)),
                "active": bool(plan.get("active", True)),
                "stockTarget": int(float(plan.get("stockTarget") or 0)),
                "keyCostCredits": int(float(plan.get("keyCostCredits") or 1)),
                "resellerEnabled": bool(plan.get("resellerEnabled", True)),
                "grantRoles": plan.get("grantRoles") or [role.strip() for role in str(plan.get("grantRolesText") or "").split(",") if role.strip()],
                "quotas": {
                    "dailyProducts": int(float(plan.get("dailyProducts") or plan.get("quotas", {}).get("dailyProducts") or 0)),
                    "dailyVideos": int(float(plan.get("dailyVideos") or plan.get("quotas", {}).get("dailyVideos") or 0)),
                },
            }
        )
        db["plans"] = [p for p in db["plans"] if p["id"] != plan_id] + [clean]
        write_db(db)
        return {"ok": True, "plans": self.plans_with_stock(db)}

    def save_settings(self, settings):
        db = read_db()
        db["settings"].update(
            {
                "pixKey": str(settings.get("pixKey", db["settings"].get("pixKey") or "")),
                "supportWhatsapp": str(settings.get("supportWhatsapp", db["settings"].get("supportWhatsapp") or "")),
                "creditPriceCents": int(float(settings.get("creditPriceCents") or db["settings"].get("creditPriceCents") or 0)),
                "minCreditPurchase": int(float(settings.get("minCreditPurchase") or db["settings"].get("minCreditPurchase") or 5)),
                "defaultCommissionPercent": min(40, int(float(settings.get("defaultCommissionPercent") or 40))),
                "siteInviteBase": normalize_public_base(settings.get("siteInviteBase", db["settings"].get("siteInviteBase") or "")),
                "kiwifyProductSiteUrl": normalize_public_base(settings.get("kiwifyProductSiteUrl", db["settings"].get("kiwifyProductSiteUrl") or "")),
            }
        )
        write_db(db)
        return {"ok": True, "settings": db["settings"]}

    def search_users(self, query):
        db = read_db()
        q = str(query or "").strip().lower()
        rows = [self.account_summary(db, user) for user in db["users"] if q in user.get("email", "").lower() or q in user.get("username", "").lower() or q in user.get("name", "").lower()]
        return {"ok": True, "users": rows[:50]}

    def set_user_access(self, user_id, hours=0, days=0, role=""):
        db = read_db()
        user = self.get_user(db, user_id)
        if not user:
            return {"ok": False, "message": "Usuario nao encontrado."}
        base = parse_iso(user.get("accessEndsAt")) or now()
        if base < now():
            base = now()
        end = base + timedelta(hours=float(hours or 0), days=float(days or 0))
        user["accessEndsAt"] = iso(end)
        user["planStatus"] = "paid"
        if role:
            add_role(user, role)
        write_db(db)
        return {"ok": True, "user": public_user(user), "dashboard": self.dashboard_for(self.admin_user(db) or user)}

    def expire_user(self, user_id):
        db = read_db()
        user = self.get_user(db, user_id)
        if not user:
            return {"ok": False, "message": "Usuario nao encontrado."}
        user["accessEndsAt"] = iso(now() - timedelta(seconds=1))
        user["planStatus"] = "expired"
        write_db(db)
        return {"ok": True, "dashboard": self.dashboard_for(self.admin_user(db) or user)}

    def generate_keys(self, admin_id, payload):
        db = read_db()
        admin = self.get_user(db, admin_id)
        if not is_admin(admin):
            return {"ok": False, "message": "Apenas admin pode gerar keys."}
        plan = self.get_plan(db, payload.get("planId"))
        if not plan:
            return {"ok": False, "message": "Plano nao encontrado."}
        count = max(1, min(500, int(float(payload.get("count") or 1))))
        duration_days = int(float(payload.get("durationDays") or plan["durationDays"]))
        prefix = str(payload.get("prefix") or "OMEGA-")
        status = "stock" if payload.get("stock", True) else "active"
        created = []
        for _ in range(count):
            key = {
                "id": new_id("key"),
                "code": make_key_code(prefix),
                "prefix": prefix,
                "planId": plan["id"],
                "planName": plan["name"],
                "durationDays": duration_days,
                "status": status,
                "createdAt": iso(now()),
                "createdBy": admin_id,
                "assignedTo": None,
                "deliveredTo": None,
                "deviceId": None,
                "activatedAt": None,
                "expiresAt": None,
                "resellerId": payload.get("resellerId") or None,
                "source": "admin",
            }
            db["keys"].append(key)
            created.append(key)
        write_db(db)
        return {"ok": True, "keys": created, "dashboard": self.dashboard_for(admin)}

    def search_keys(self, query=""):
        db = read_db()
        q = str(query or "").strip().lower()
        rows = [
            {**key, "owner": self.owner(db, key.get("assignedTo") or key.get("deliveredTo") or key.get("resellerId"))}
            for key in db["keys"]
            if not q
            or q in key.get("code", "").lower()
            or q in key.get("status", "").lower()
            or q in key.get("planName", "").lower()
            or q in (self.owner(db, key.get("assignedTo") or key.get("deliveredTo") or key.get("resellerId")).get("email", "").lower())
        ]
        return {"ok": True, "keys": rows[-200:][::-1]}

    def update_key_status(self, key_id, action):
        db = read_db()
        key = self.get_key(db, key_id)
        if not key:
            return {"ok": False, "message": "Key nao encontrada."}
        action = str(action or "").lower()
        if action == "reset":
            key.update({"status": "stock", "assignedTo": None, "deliveredTo": None, "deviceId": None, "activatedAt": None, "expiresAt": None})
        elif action in ("cancel", "cancelled"):
            key["status"] = "cancelled"
        elif action in ("pause", "paused"):
            key["status"] = "paused"
        elif action in ("activate", "active"):
            key["status"] = "active"
        elif action == "stock":
            key["status"] = "stock"
        else:
            return {"ok": False, "message": "Acao invalida."}
        write_db(db)
        return {"ok": True, "key": key}

    def redeem_key(self, user_id, code, device_id):
        db = read_db()
        user = self.get_user(db, user_id)
        code = str(code or "").strip().upper()
        key = next((k for k in db["keys"] if k.get("code", "").upper() == code), None)
        if not user or not key:
            return {"ok": False, "message": "Key nao encontrada."}
        if key.get("status") in ("cancelled", "paused", "used"):
            return {"ok": False, "message": f"Key esta {key.get('status')}."}
        if key.get("assignedTo") and key.get("assignedTo") != user_id:
            return {"ok": False, "message": "Key ja esta em outro dispositivo/usuario."}

        plan = self.get_plan(db, key.get("planId")) or {"durationDays": key.get("durationDays", 30), "id": key.get("planId"), "name": key.get("planName")}
        base = parse_iso(user.get("accessEndsAt")) or now()
        if base < now():
            base = now()
        duration = int(key.get("durationDays") or plan.get("durationDays") or 30)
        end = base + timedelta(days=duration)
        user["accessEndsAt"] = iso(end)
        user["currentPlanId"] = plan.get("id")
        user["planStatus"] = "paid"
        add_role(user, "permanent" if duration >= 3650 else "monthly")
        for role in plan.get("grantRoles", []):
            add_role(user, role)
        key.update(
            {
                "status": "used",
                "assignedTo": user_id,
                "deliveredTo": user_id,
                "deviceId": str(device_id or ""),
                "activatedAt": iso(now()),
                "expiresAt": iso(end),
            }
        )
        self.add_message(db, "system", user_id, f"Plano ativado com a key {key['code']}.", "key")
        write_db(db)
        return {"ok": True, "user": public_user(user), "dashboard": self.dashboard_for(user), "key": key}

    def create_payment_request(self, user_id, payload):
        db = read_db()
        user = self.get_user(db, user_id)
        if not user:
            return {"ok": False, "message": "Usuario nao encontrado."}
        pay_type = payload.get("type") or "plan"
        plan = self.get_plan(db, payload.get("planId")) if pay_type == "plan" else None
        credits = int(float(payload.get("credits") or 0))
        if pay_type == "plan" and not plan:
            return {"ok": False, "message": "Plano nao encontrado."}
        if pay_type == "credits":
            minimum = int(db["settings"].get("minCreditPurchase") or 5)
            if credits < minimum:
                return {"ok": False, "message": f"Compra minima: {minimum} creditos."}

        amount = int(plan["priceCents"]) if plan else credits * int(db["settings"].get("creditPriceCents") or 0)
        expires_at = now() + timedelta(minutes=30)
        pix_key = db["settings"].get("pixKey")
        qr_text = f"PIX:{pix_key}|VALOR:{money(amount)}|PEDIDO:{new_id('checkout')}"
        payment = {
            "id": new_id("pay"),
            "userId": user_id,
            "userName": user.get("name"),
            "userEmail": user.get("email"),
            "type": pay_type,
            "planId": plan["id"] if plan else None,
            "planName": plan["name"] if plan else None,
            "credits": credits,
            "amountCents": amount,
            "pixKey": pix_key,
            "qrText": qr_text,
            "qrDataUrl": payment_qr_data_url(qr_text),
            "status": "pending_payment",
            "createdAt": iso(now()),
            "expiresAt": iso(expires_at),
            "paidClickedAt": None,
            "reviewedAt": None,
            "deliveredKeyId": None,
            "referralOwner": user.get("referredBy"),
            "referralRole": user.get("referredByRole"),
        }
        db["payments"].append(payment)
        self.add_message(
            db,
            "system",
            user_id,
            f"Carrinho aberto: {payment_label(payment)}. Valido por 30 minutos.",
            "payment",
            {"paymentId": payment["id"]},
        )
        write_db(db)
        return {"ok": True, "payment": payment, "dashboard": self.dashboard_for(user)}

    def mark_paid(self, user_id, payment_id):
        db = read_db()
        user = self.get_user(db, user_id)
        payment = self.get_payment(db, payment_id)
        if not user or not payment or payment.get("userId") != user_id:
            return {"ok": False, "message": "Pagamento nao encontrado."}
        expires_at = parse_iso(payment.get("expiresAt"))
        if expires_at and expires_at < now():
            payment["status"] = "expired"
            write_db(db)
            return {"ok": False, "expired": True, "message": "Carrinho expirou. Gere um novo pagamento."}
        payment["status"] = "waiting_owner"
        payment["paidClickedAt"] = iso(now())
        admin = self.admin_user(db)
        self.add_message(
            db,
            user_id,
            admin["id"] if admin else None,
            f"{user.get('name')} clicou em ja paguei: {payment_label(payment)}.",
            "payment_review",
            {"paymentId": payment_id},
        )
        write_db(db)
        return {"ok": True, "dashboard": self.dashboard_for(user)}

    def review_payment(self, admin_id, payment_id, approve):
        db = read_db()
        admin = self.get_user(db, admin_id)
        payment = self.get_payment(db, payment_id)
        if not is_admin(admin) or not payment:
            return {"ok": False, "message": "Sem permissao ou pagamento nao encontrado."}
        buyer = self.get_user(db, payment.get("userId"))
        if not buyer:
            return {"ok": False, "message": "Comprador nao encontrado."}
        payment["reviewedAt"] = iso(now())
        if not approve:
            payment["status"] = "refused"
            self.add_message(db, admin_id, buyer["id"], f"Pagamento recusado: {payment_label(payment)}.", "payment")
            write_db(db)
            return {"ok": True, "payment": payment, "dashboard": self.dashboard_for(admin)}

        payment["status"] = "confirmed"
        if payment.get("type") == "credits":
            buyer["credits"] = int(buyer.get("credits", 0)) + int(payment.get("credits") or 0)
            if has_role(buyer, "pending_reseller") and buyer["credits"] >= int(db["settings"].get("minCreditPurchase") or 5):
                remove_role(buyer, "pending_reseller")
                add_role(buyer, "reseller")
            self.add_message(db, admin_id, buyer["id"], f"Pagamento confirmado. {payment.get('credits')} creditos adicionados.", "credits")
        else:
            plan = self.get_plan(db, payment.get("planId")) or {}
            for role in plan.get("grantRoles", []):
                add_role(buyer, role)
            key = self.deliver_plan_key(db, buyer, payment.get("planId"), admin_id)
            payment["deliveredKeyId"] = key["id"]
            self.add_message(
                db,
                admin_id,
                buyer["id"],
                f"Pagamento confirmado. Sua key: {key['code']}. Va em Adicionar key para ativar no dispositivo.",
                "key",
                {"keyId": key["id"], "code": key["code"]},
            )
            self.create_commission_if_needed(db, payment, buyer)
        write_db(db)
        return {"ok": True, "payment": payment, "dashboard": self.dashboard_for(admin)}

    def apply_reseller(self, user_id, fields):
        db = read_db()
        user = self.get_user(db, user_id)
        if not user:
            return {"ok": False, "message": "Usuario nao encontrado."}
        app = {
            "id": new_id("app"),
            "type": "reseller",
            "userId": user_id,
            "userName": user.get("name"),
            "userEmail": user.get("email"),
            "status": "pending",
            "createdAt": iso(now()),
            "fields": {
                "age": str(fields.get("age") or ""),
                "experience": str(fields.get("experience") or ""),
                "hasStore": str(fields.get("hasStore") or ""),
                "audienceSize": str(fields.get("audienceSize") or ""),
            },
        }
        db["applications"].append(app)
        self.add_message(db, user_id, self.admin_user(db)["id"], f"Nova inscricao de revendedor: {user.get('name')}.", "application", {"applicationId": app["id"]})
        write_db(db)
        return {"ok": True, "application": app, "dashboard": self.dashboard_for(user)}

    def apply_promoter(self, user_id, fields):
        db = read_db()
        user = self.get_user(db, user_id)
        if not user:
            return {"ok": False, "message": "Usuario nao encontrado."}
        app = {
            "id": new_id("app"),
            "type": "promoter",
            "userId": user_id,
            "userName": user.get("name"),
            "userEmail": user.get("email"),
            "status": "pending",
            "createdAt": iso(now()),
            "fields": {
                "socialLinks": str(fields.get("socialLinks") or ""),
                "schedule": str(fields.get("schedule") or ""),
                "experience": str(fields.get("experience") or ""),
            },
        }
        db["applications"].append(app)
        self.add_message(db, user_id, self.admin_user(db)["id"], f"Nova inscricao de divulgador: {user.get('name')}.", "application", {"applicationId": app["id"]})
        write_db(db)
        return {"ok": True, "application": app, "dashboard": self.dashboard_for(user)}

    def review_application(self, admin_id, application_id, approve):
        db = read_db()
        admin = self.get_user(db, admin_id)
        app = next((item for item in db["applications"] if item.get("id") == application_id), None)
        if not is_admin(admin) or not app:
            return {"ok": False, "message": "Sem permissao ou inscricao nao encontrada."}
        user = self.get_user(db, app["userId"])
        app["status"] = "approved" if approve else "refused"
        app["reviewedAt"] = iso(now())
        if approve and app["type"] == "reseller":
            add_role(user, "pending_reseller")
            user["resellerCartExpiresAt"] = iso(now() + timedelta(hours=24))
            user["resellerInviteCode"] = user.get("resellerInviteCode") or f"rev-{strip_invite_prefix(user['inviteCode'])}"
            self.add_message(db, admin_id, user["id"], "Revenda aprovada. Voce tem 24h para comprar no minimo 5 creditos.", "application")
        elif approve and app["type"] == "promoter":
            add_role(user, "promoter")
            user["promoterInviteCode"] = user.get("promoterInviteCode") or f"div-{strip_invite_prefix(user['inviteCode'])}"
            user["commissionPercent"] = min(40, int(db["settings"].get("defaultCommissionPercent") or 40))
            self.add_message(db, admin_id, user["id"], "Divulgador aprovado. Seu link de convite foi liberado.", "application")
        else:
            self.add_message(db, admin_id, user["id"], f"Inscricao {app['type']} recusada.", "application")
        write_db(db)
        return {"ok": True, "application": app, "dashboard": self.dashboard_for(admin)}

    def reseller_buy_credits(self, user_id, credits):
        return self.create_payment_request(user_id, {"type": "credits", "credits": credits})

    def reseller_generate_key(self, user_id, plan_id, prefix="OMEGA-"):
        db = read_db()
        user = self.get_user(db, user_id)
        plan = self.get_plan(db, plan_id)
        if not user or not plan:
            return {"ok": False, "message": "Usuario ou plano nao encontrado."}
        if not has_role(user, "reseller"):
            return {"ok": False, "message": "Apenas revendedores aprovados podem gerar keys."}
        cost = int(plan.get("keyCostCredits") or 1)
        if int(user.get("credits", 0)) < cost:
            return {"ok": False, "message": "Creditos insuficientes."}
        user["credits"] = int(user.get("credits", 0)) - cost
        key = {
            "id": new_id("key"),
            "code": make_key_code(prefix),
            "prefix": prefix,
            "planId": plan["id"],
            "planName": plan["name"],
            "durationDays": int(plan["durationDays"]),
            "status": "active",
            "createdAt": iso(now()),
            "createdBy": user_id,
            "assignedTo": None,
            "deliveredTo": user_id,
            "deviceId": None,
            "activatedAt": None,
            "expiresAt": None,
            "resellerId": user_id,
            "source": "reseller",
            "creditCost": cost,
        }
        db["keys"].append(key)
        self.add_message(db, "system", user_id, f"Key gerada para revenda: {key['code']}.", "key", {"keyId": key["id"], "code": key["code"]})
        write_db(db)
        return {"ok": True, "key": key, "dashboard": self.dashboard_for(user)}

    def save_profile(self, user_id, profile):
        db = read_db()
        user = self.get_user(db, user_id)
        if not user:
            return {"ok": False, "message": "Usuario nao encontrado."}
        user["profile"] = {
            "photo": str(profile.get("photo") or ""),
            "bio": str(profile.get("bio") or ""),
            "social": profile.get("social") or user.get("profile", {}).get("social", {}),
        }
        write_db(db)
        return {"ok": True, "user": public_user(user), "dashboard": self.dashboard_for(user)}

    def send_dm(self, from_user_id, to_user_id, text):
        db = read_db()
        sender = self.get_user(db, from_user_id)
        target = self.get_user(db, to_user_id) or self.admin_user(db)
        if not sender or not target:
            return {"ok": False, "message": "Usuario nao encontrado."}
        self.add_message(db, sender["id"], target["id"], str(text or "")[:1200], "dm")
        write_db(db)
        return {"ok": True, "dashboard": self.dashboard_for(sender)}

    def mark_thread_read(self, user_id, peer_id):
        db = read_db()
        user = self.get_user(db, user_id)
        if not user:
            return {"ok": False, "message": "Usuario nao encontrado."}
        for message in db["messages"]:
            if message.get("kind") == "general":
                continue
            if message.get("toUserId") == user_id and message.get("fromUserId") == peer_id:
                message["read"] = True
        write_db(db)
        return {"ok": True, "dashboard": self.dashboard_for(user)}

    def save_permissions(self, role, permissions):
        db = read_db()
        role = str(role or "").strip()
        if role not in db["permissions"]:
            db["permissions"][role] = {}
        for key in DEFAULT_PERMISSIONS["free"].keys():
            if key in permissions:
                db["permissions"][role][key] = bool(permissions[key])
        write_db(db)
        return {"ok": True, "permissions": db["permissions"]}

    def create_role(self, admin_id, role, label=""):
        db = read_db()
        admin = self.get_user(db, admin_id)
        if not is_admin(admin):
            return {"ok": False, "message": "Apenas admin pode criar cargos."}
        role = str(role or "").strip().lower().replace(" ", "-")
        if not role:
            return {"ok": False, "message": "Informe o nome do cargo."}
        db["permissions"].setdefault(role, dict(DEFAULT_PERMISSIONS["free"]))
        db.setdefault("roleLabels", {})[role] = str(label or role)
        write_db(db)
        return {"ok": True, "permissions": db["permissions"], "roleLabels": db.get("roleLabels", {})}

    def assign_user_roles(self, admin_id, target_user_id, roles):
        db = read_db()
        admin = self.get_user(db, admin_id)
        target = self.get_user(db, target_user_id)
        if not is_admin(admin) or not target:
            return {"ok": False, "message": "Sem permissao ou usuario nao encontrado."}
        clean_roles = [str(role).strip() for role in (roles or []) if str(role).strip()]
        if is_admin(target) and "admin" not in clean_roles:
            clean_roles.append("admin")
        target["roles"] = clean_roles or ["free"]
        target["role"] = "admin" if "admin" in target["roles"] else target["roles"][0]
        write_db(db)
        return {"ok": True, "dashboard": self.dashboard_for(admin)}

    def connect_social(self, user_id, platform, handle):
        db = read_db()
        user = self.get_user(db, user_id)
        platform = str(platform or "").lower()
        if platform not in ("tiktok", "instagram", "youtube"):
            return {"ok": False, "message": "Rede social invalida."}
        existing = next((s for s in db["socialConnections"] if s.get("userId") == user_id and s.get("platform") == platform), None)
        if not existing:
            existing = {"id": new_id("social"), "userId": user_id, "platform": platform, "createdAt": iso(now())}
            db["socialConnections"].append(existing)
        existing.update({"handle": str(handle or ""), "status": "connected", "updatedAt": iso(now())})
        user.setdefault("profile", {}).setdefault("social", {})[platform] = str(handle or "")
        write_db(db)
        return {"ok": True, "dashboard": self.dashboard_for(user)}

    def social_login(self, platform):
        urls = {
            "tiktok": "https://www.tiktok.com/login",
            "instagram": "https://www.instagram.com/accounts/login/",
            "youtube": "https://accounts.google.com/ServiceLogin?service=youtube",
        }
        platform = str(platform or "").lower()
        if platform not in urls:
            return {"ok": False, "message": "Rede social invalida."}
        return open_chrome_profile(SOCIAL_SESSION_DIR / platform, urls[platform])

    def kiwify_login(self):
        return open_chrome_profile(SESSION_DIR, "https://dashboard.kiwify.com.br", debug_port=9222)

    def run_factory(self, user_id, niche):
        db = read_db()
        user = self.get_user(db, user_id)
        if not user:
            return {"ok": False, "message": "Usuario nao encontrado."}
        if not is_admin(user) and not access_status(user)["active"]:
            return {"ok": False, "expired": True, "message": "Seu teste acabou. Adquira um plano ou ative uma key."}
        script = BASE / "autopilot" / "scripts" / "kiwifarm-autopilot.mjs"
        if not script.exists():
            return {"ok": False, "message": "Conector de automacao nao encontrado."}
        node = find_node()
        ensure_dirs()
        env = os.environ.copy()
        env["KIWIFY_CHROME_PROFILE"] = str(SESSION_DIR)
        env["KIWIFY_CDP_PORT"] = "9222"
        env["KIWIFARM_DB"] = str(DB_PATH)
        env["KIWIFY_PRODUCT_SITE_URL"] = db["settings"].get("kiwifyProductSiteUrl") or "https://kiwify.com.br"
        with LOG_PATH.open("a", encoding="utf-8") as log_file:
            subprocess.Popen(
                [node, str(script), "--run", "--publish", f"--niche={niche}", f"--owner-id={user_id}"],
                cwd=str(BASE),
                stdout=log_file,
                stderr=log_file,
                stdin=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                env=env,
            )
        return {"ok": True, "message": "Automacao iniciada. O ebook e a capa serao gerados; a Kiwify sera preenchida quando o formulario estiver acessivel no Chrome."}

    def open_products_folder(self):
        PRODUCTS_DIR.mkdir(parents=True, exist_ok=True)
        os.startfile(PRODUCTS_DIR)
        return {"ok": True}

    def plans_with_stock(self, db):
        return [{**plan, "stock": stock_count(db, plan["id"])} for plan in db["plans"]]

    def visible_keys(self, db, user):
        if is_admin(user):
            rows = db["keys"][-120:]
        else:
            rows = [
                key
                for key in db["keys"]
                if key.get("deliveredTo") == user["id"] or key.get("assignedTo") == user["id"] or key.get("resellerId") == user["id"]
            ][-80:]
        return [{**key, "owner": self.owner(db, key.get("assignedTo") or key.get("deliveredTo") or key.get("resellerId"))} for key in rows][::-1]

    def visible_payments(self, db, user):
        changed = False
        for payment in db["payments"]:
            if payment.get("status") == "pending_payment":
                expires_at = parse_iso(payment.get("expiresAt"))
                if expires_at and expires_at < now():
                    payment["status"] = "expired"
                    changed = True
        if changed:
            write_db(db)
        rows = db["payments"] if is_admin(user) else [p for p in db["payments"] if p.get("userId") == user["id"]]
        return rows[-80:][::-1]

    def visible_applications(self, db, user):
        if is_admin(user):
            return db["applications"][-100:][::-1]
        return [a for a in db["applications"] if a.get("userId") == user["id"]][::-1]

    def visible_messages(self, db, user):
        if is_admin(user):
            rows = [m for m in db["messages"] if m.get("kind") != "general" and (m.get("toUserId") in (None, user["id"]) or m.get("fromUserId") != "system")]
        else:
            rows = [m for m in db["messages"] if m.get("kind") != "general" and (m.get("toUserId") == user["id"] or m.get("fromUserId") == user["id"])]
        return rows[-120:][::-1]

    def account_summary(self, db, user):
        products = [p for p in db["products"] if p.get("ownerId") == user["id"]]
        keys = [k for k in db["keys"] if k.get("assignedTo") == user["id"] or k.get("deliveredTo") == user["id"] or k.get("resellerId") == user["id"]]
        return {
            **public_user(user),
            "products": len(products),
            "keys": len(keys),
            "estimatedRevenueCents": sum(int(p.get("estimatedRevenueCents", 0)) for p in products),
        }

    def owner(self, db, owner_id):
        user = self.get_user(db, owner_id)
        return public_user(user) if user else {"name": "Conta", "email": "", "id": None}

    def contacts(self, db, user):
        rows = []
        for contact in db["users"]:
            if contact.get("id") == user.get("id"):
                continue
            if not is_admin(user) and not is_admin(contact):
                continue
            rows.append(
                {
                    "id": contact.get("id"),
                    "name": contact.get("name"),
                    "email": contact.get("email"),
                    "username": contact.get("username"),
                    "role": contact.get("role"),
                    "roles": contact.get("roles", []),
                    "roleLabel": ", ".join(ROLE_LABELS.get(role, role) for role in contact.get("roles", [])),
                    "profile": contact.get("profile", {}),
                }
            )
        return rows

    def dashboard_stats(self, db):
        return {
            "accounts": len(db["users"]),
            "products": len(db["products"]),
            "estimatedRevenueCents": sum(int(p.get("estimatedRevenueCents", 0)) for p in db["products"]),
            "keys": len(db["keys"]),
        }

    def rankings(self, db):
        promoters = [u for u in db["users"] if has_role(u, "promoter")]
        resellers = [u for u in db["users"] if has_role(u, "reseller")]
        promoter_rows = []
        for user in promoters:
            invited = [u for u in db["users"] if u.get("referredBy") == user["id"]]
            commissions = [c for c in db["commissions"] if c.get("promoterId") == user["id"]]
            promoter_rows.append(
                {
                    "id": user["id"],
                    "name": user["name"],
                    "email": user["email"],
                    "inviteCode": user.get("promoterInviteCode") or user.get("inviteCode"),
                    "invitedCount": len(invited),
                    "customers": len([u for u in invited if u.get("planStatus") == "paid"]),
                    "commissionCents": sum(int(c.get("amountCents", 0)) for c in commissions),
                    "invited": [public_user(u) for u in invited],
                }
            )
        reseller_rows = []
        for user in resellers:
            keys = [k for k in db["keys"] if k.get("resellerId") == user["id"]]
            reseller_rows.append(
                {
                    "id": user["id"],
                    "name": user["name"],
                    "email": user["email"],
                    "inviteCode": user.get("resellerInviteCode") or user.get("inviteCode"),
                    "credits": int(user.get("credits", 0)),
                    "keysGenerated": len(keys),
                    "creditsSpent": sum(int(k.get("creditCost", 0)) for k in keys),
                }
            )
        promoter_rows.sort(key=lambda item: item["invitedCount"], reverse=True)
        reseller_rows.sort(key=lambda item: item["creditsSpent"], reverse=True)
        return {"promoters": promoter_rows, "resellers": reseller_rows}

    def add_message(self, db, from_user_id, to_user_id, text, kind="dm", payload=None):
        sender = self.get_user(db, from_user_id) if from_user_id and from_user_id != "system" else None
        target = self.get_user(db, to_user_id) if to_user_id else None
        db["messages"].append(
            {
                "id": new_id("msg"),
                "fromUserId": from_user_id,
                "fromName": sender.get("name") if sender else "KiwiFarm",
                "toUserId": to_user_id,
                "toName": target.get("name") if target else "Owner",
                "text": str(text or ""),
                "kind": kind,
                "payload": payload or {},
                "createdAt": iso(now()),
                "read": False,
            }
        )

    def deliver_plan_key(self, db, buyer, plan_id, admin_id):
        plan = self.get_plan(db, plan_id)
        key = next((k for k in db["keys"] if k.get("planId") == plan_id and k.get("status") == "stock"), None)
        if not key:
            key = {
                "id": new_id("key"),
                "code": make_key_code("OMEGA-"),
                "prefix": "OMEGA-",
                "planId": plan["id"],
                "planName": plan["name"],
                "durationDays": int(plan["durationDays"]),
                "status": "active",
                "createdAt": iso(now()),
                "createdBy": admin_id,
                "assignedTo": None,
                "deliveredTo": None,
                "deviceId": None,
                "activatedAt": None,
                "expiresAt": None,
                "resellerId": None,
                "source": "auto-stock",
            }
            db["keys"].append(key)
        key["status"] = "active"
        key["deliveredTo"] = buyer["id"]
        key["deliveredAt"] = iso(now())
        return key

    def create_commission_if_needed(self, db, payment, buyer):
        promoter_id = buyer.get("referredBy") if buyer.get("referredByRole") == "promoter" else None
        promoter = self.get_user(db, promoter_id)
        if not promoter or not has_role(promoter, "promoter"):
            return
        percent = min(40, int(promoter.get("commissionPercent") or db["settings"].get("defaultCommissionPercent") or 40))
        amount = int(payment.get("amountCents") or 0) * percent // 100
        db["commissions"].append(
            {
                "id": new_id("com"),
                "paymentId": payment["id"],
                "promoterId": promoter["id"],
                "buyerId": buyer["id"],
                "product": payment.get("planName"),
                "percent": percent,
                "amountCents": amount,
                "createdAt": iso(now()),
                "status": "pending",
            }
        )
        self.add_message(db, "system", promoter["id"], f"Comissao registrada: {money(amount)} por {buyer.get('name')}.", "commission")

    def find_inviter(self, db, code):
        value = clean_invite_code(code)
        if not value:
            return None
        for user in db["users"]:
            candidates = [user.get("inviteCode"), user.get("promoterInviteCode"), user.get("resellerInviteCode")]
            clean_candidates = [clean_invite_code(item) for item in candidates]
            if value in clean_candidates:
                role = "promoter" if value == clean_invite_code(user.get("promoterInviteCode")) else "reseller" if value == clean_invite_code(user.get("resellerInviteCode")) else user.get("role")
                return {"id": user["id"], "role": role}
        return None

    def get_user(self, db, user_id):
        return next((user for user in db["users"] if user.get("id") == user_id), None)

    def get_plan(self, db, plan_id):
        return next((plan for plan in db["plans"] if plan.get("id") == plan_id), None)

    def get_key(self, db, key_id):
        return next((key for key in db["keys"] if key.get("id") == key_id), None)

    def get_payment(self, db, payment_id):
        return next((payment for payment in db["payments"] if payment.get("id") == payment_id), None)

    def admin_user(self, db):
        return next((u for u in db["users"] if is_admin(u)), None)


def clean_invite_code(code):
    raw = str(code or "").strip()
    if not raw:
        return ""
    try:
        parsed = urlparse(raw)
        if parsed.path:
            raw = parsed.path
    except ValueError:
        pass
    raw = raw.split("?")[0].split("#")[0].strip().strip("/")
    if "/" in raw:
        raw = raw.rsplit("/", 1)[-1]
    return unquote(raw).strip().lower()


def normalize_public_base(value):
    raw = str(value or "").strip().rstrip("/")
    if not raw or "kiwifarm.local" in raw.lower():
        return ""
    if raw.lower().startswith("https//"):
        raw = "https://" + raw[7:]
    elif raw.lower().startswith("http//"):
        raw = "http://" + raw[6:]
    if not raw.startswith(("http://", "https://")):
        raw = f"https://{raw}"
    for suffix in ("/convite", "/revendedor", "/divulgador"):
        if raw.lower().endswith(suffix):
            raw = raw[: -len(suffix)]
    return raw.rstrip("/")


def payment_label(payment):
    if payment.get("type") == "credits":
        return f"{payment.get('credits')} creditos - {money(int(payment.get('amountCents') or 0))}"
    return f"{payment.get('planName')} - {money(int(payment.get('amountCents') or 0))}"


if __name__ == "__main__":
    ensure_dirs()
    api = Api()
    window = webview.create_window(
        "KiwiFarm",
        str(APP_HTML),
        js_api=api,
        width=1360,
        height=860,
        min_size=(1120, 700),
        background_color="#07070d",
    )
    webview.start(debug=False)
