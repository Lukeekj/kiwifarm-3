def create_window(*args, **kwargs):
    return None


def start(*args, **kwargs):
    return None
