KiwiFarm Vercel Next

Use este pacote no Vercel se os ZIPs anteriores retornaram 404.

Como subir:

1. Envie KiwiFarm-Vercel-Next.zip para um repositorio GitHub.
2. No Vercel, importe esse repositorio.
3. Framework preset: Next.js.
4. Build command: pnpm run build.
5. Output directory: deixe vazio.
6. Root directory: a pasta onde estao package.json, app/ e public/.

Se ainda der 404:

- Voce esta abrindo deploy antigo ou importou a pasta errada.
- Confira no Vercel se package.json esta na raiz do projeto.
- Nao suba a pasta outputs inteira. Suba apenas o conteudo de KiwiFarm-Vercel-Next.
- A URL correta deve mostrar KiwiFarm Mobile, nao a tela 404 do Vercel.

Dominio:

Para usar https://kiwifarm.mobile, adicione esse dominio em Settings > Domains e configure o DNS conforme o Vercel pedir.
