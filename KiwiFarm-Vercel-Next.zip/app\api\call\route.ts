export const dynamic = "force-dynamic";

type AnyRecord = Record<string, any>;

const adminUsers = [
  {
    id: "admin-primary",
    email: "luisfelipegarciarodrigues864@gmail.com",
    username: "luisadmin",
    name: "Luis Felipe",
    role: "admin",
    roles: ["admin"],
    password: "100513lf",
    createdAt: new Date().toISOString(),
    planStatus: "admin",
    credits: 0,
    inviteCode: "luis-admin"
  },
  {
    id: "admin-secondary",
    email: "luisfelipe@kiwifarm.mobile",
    username: "luisfelipe",
    name: "Luis Felipe",
    role: "admin",
    roles: ["admin"],
    password: "luisfelipe100513Lf@",
    createdAt: new Date().toISOString(),
    planStatus: "admin",
    credits: 0,
    inviteCode: "luisfelipe"
  }
];

const defaultPlans = [
  { id: "starter", name: "Mensal Basic", priceCents: 1990, durationDays: 30, active: true, stockTarget: 25, keyCostCredits: 2, resellerEnabled: true, grantRoles: ["monthly"], quotas: { dailyProducts: 2, dailyVideos: 3 } },
  { id: "pro", name: "Mensal Pro", priceCents: 4990, durationDays: 30, active: true, stockTarget: 50, keyCostCredits: 3, resellerEnabled: true, grantRoles: ["monthly"], quotas: { dailyProducts: 5, dailyVideos: 8 } },
  { id: "permanent-basic", name: "Permanente Basic", priceCents: 9990, durationDays: 3650, active: true, stockTarget: 15, keyCostCredits: 5, resellerEnabled: true, grantRoles: ["permanent"], quotas: { dailyProducts: 2, dailyVideos: 3 } }
];

const defaultSettings = {
  pixKey: "configure-sua-chave-pix-no-admin",
  supportWhatsapp: "configure seu WhatsApp no admin",
  creditPriceCents: 1000,
  minCreditPurchase: 5,
  defaultCommissionPercent: 40,
  siteInviteBase: "https://kiwifarm.mobile",
  kiwifyProductSiteUrl: "https://kiwify.com.br"
};

function getStore() {
  const globalStore = globalThis as any;
  if (!globalStore.__KIWIFARM_STORE__) {
    globalStore.__KIWIFARM_STORE__ = {
      users: adminUsers.map((user) => ({ ...user })),
      plans: defaultPlans.map((plan) => ({ ...plan })),
      settings: { ...defaultSettings },
      keys: [],
      products: [],
      payments: [],
      messages: [],
      applications: [],
      commissions: [],
      socialConnections: []
    };
  }
  return globalStore.__KIWIFARM_STORE__;
}

function nowIso() {
  return new Date().toISOString();
}

function addMs(ms: number) {
  return new Date(Date.now() + ms).toISOString();
}

function id(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
}

function isAdmin(user: AnyRecord) {
  return Boolean(user && ((user.roles || []).includes("admin") || user.role === "admin"));
}

function hasRole(user: AnyRecord, role: string) {
  return (user?.roles || []).includes(role);
}

function publicUser(user: AnyRecord): AnyRecord {
  const access = accessStatus(user);
  const { password, ...clean } = user;
  return {
    ...clean,
    roleLabel: user.role === "admin" ? "Admin" : user.role === "reseller" ? "Revendedor" : user.role === "promoter" ? "Divulgador" : user.role === "permanent" ? "Membro permanente" : user.role === "monthly" ? "Membro mensal" : "Membro gratis",
    access
  };
}

function accessStatus(user: AnyRecord): AnyRecord {
  if (isAdmin(user)) return { active: true, kind: "admin", endsAt: null, remainingSeconds: 999999999 };
  const endsAt = user.accessEndsAt ? new Date(user.accessEndsAt).getTime() : 0;
  const remainingSeconds = Math.max(0, Math.floor((endsAt - Date.now()) / 1000));
  return { active: remainingSeconds > 0, kind: user.planStatus || "trial", endsAt: user.accessEndsAt || null, remainingSeconds };
}

function planWithStock(store: AnyRecord, plan: AnyRecord) {
  return { ...plan, stock: store.keys.filter((key: AnyRecord) => key.planId === plan.id && key.status === "stock").length };
}

function dashboardFor(store: AnyRecord, user: AnyRecord) {
  const products = isAdmin(user) ? store.products : store.products.filter((product: AnyRecord) => product.ownerId === user.id);
  const messages = visibleMessages(store, user);
  return {
    metrics: {
      accounts: isAdmin(user) ? store.users.length : 1,
      products: products.length,
      activeProducts: products.filter((p: AnyRecord) => ["active", "winner", "creating", "prepared", "kiwify_opened", "kiwify_submitted"].includes(p.status)).length,
      estimatedRevenueCents: products.reduce((sum: number, p: AnyRecord) => sum + Number(p.estimatedRevenueCents || 0), 0),
      pendingPayments: store.payments.filter((p: AnyRecord) => p.status === "waiting_owner").length,
      keyStock: store.keys.filter((key: AnyRecord) => key.status === "stock").length,
      credits: Number(user.credits || 0)
    },
    products: products.map((p: AnyRecord) => ({ ...p, owner: owner(store, p.ownerId) })),
    accounts: isAdmin(user) ? store.users.map((u: AnyRecord) => accountSummary(store, u)) : [],
    plans: store.plans.map((p: AnyRecord) => planWithStock(store, p)),
    settings: store.settings,
    permissions: {},
    roleLabels: {},
    keys: visibleKeys(store, user),
    payments: visiblePayments(store, user),
    messages,
    applications: isAdmin(user) ? store.applications.slice(-100).reverse() : store.applications.filter((a: AnyRecord) => a.userId === user.id).reverse(),
    rankings: isAdmin(user) ? rankings(store) : {},
    socialConnections: store.socialConnections.filter((s: AnyRecord) => isAdmin(user) || s.userId === user.id),
    commissions: store.commissions.filter((c: AnyRecord) => isAdmin(user) || c.promoterId === user.id),
    contacts: contacts(store, user)
  };
}

function owner(store: AnyRecord, ownerId: string): AnyRecord {
  const user = store.users.find((u: AnyRecord) => u.id === ownerId);
  return user ? publicUser(user) : { id: null, name: "Conta", email: "" };
}

function accountSummary(store: AnyRecord, user: AnyRecord) {
  const products = store.products.filter((p: AnyRecord) => p.ownerId === user.id);
  const keys = store.keys.filter((k: AnyRecord) => k.assignedTo === user.id || k.deliveredTo === user.id || k.resellerId === user.id);
  return { ...publicUser(user), products: products.length, keys: keys.length, estimatedRevenueCents: products.reduce((sum: number, p: AnyRecord) => sum + Number(p.estimatedRevenueCents || 0), 0) };
}

function visibleKeys(store: AnyRecord, user: AnyRecord) {
  const rows = isAdmin(user)
    ? store.keys.slice(-120)
    : store.keys.filter((key: AnyRecord) => key.deliveredTo === user.id || key.assignedTo === user.id || key.resellerId === user.id).slice(-80);
  return rows.map((key: AnyRecord) => ({ ...key, owner: owner(store, key.assignedTo || key.deliveredTo || key.resellerId) })).reverse();
}

function visiblePayments(store: AnyRecord, user: AnyRecord) {
  const rows = isAdmin(user) ? store.payments : store.payments.filter((p: AnyRecord) => p.userId === user.id);
  return rows.slice(-80).reverse();
}

function visibleMessages(store: AnyRecord, user: AnyRecord) {
  const rows = isAdmin(user)
    ? store.messages.filter((m: AnyRecord) => m.kind !== "general")
    : store.messages.filter((m: AnyRecord) => m.kind !== "general" && (m.toUserId === user.id || m.fromUserId === user.id));
  return rows.slice(-120).reverse();
}

function contacts(store: AnyRecord, user: AnyRecord) {
  if (isAdmin(user)) return store.users.filter((u: AnyRecord) => u.id !== user.id).map(publicUser);
  return store.users.filter((u: AnyRecord) => isAdmin(u)).map(publicUser).slice(0, 1);
}

function rankings(store: AnyRecord) {
  const resellers = store.users.filter((u: AnyRecord) => hasRole(u, "reseller") || hasRole(u, "pending_reseller")).map((user: AnyRecord) => ({
    id: user.id,
    name: user.name,
    email: user.email,
    inviteCode: user.resellerInviteCode || `rev-${user.inviteCode}`,
    credits: user.credits || 0,
    keysGenerated: store.keys.filter((k: AnyRecord) => k.resellerId === user.id).length,
    creditsSpent: store.keys.filter((k: AnyRecord) => k.resellerId === user.id).reduce((sum: number, k: AnyRecord) => sum + Number(k.creditCost || 0), 0)
  }));
  const promoters = store.users.filter((u: AnyRecord) => hasRole(u, "promoter")).map((user: AnyRecord) => {
    const invited = store.users.filter((u: AnyRecord) => u.referredBy === user.id);
    return { id: user.id, name: user.name, email: user.email, inviteCode: user.promoterInviteCode || `div-${user.inviteCode}`, invitedCount: invited.length, customers: invited.filter((u: AnyRecord) => u.planStatus === "paid").length, commissionCents: 0, invited: invited.map(publicUser) };
  });
  return { resellers, promoters };
}

function makeKey(prefix = "OMEGA-") {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const part = () => Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  return `${prefix || ""}${part()}-${part()}-${part()}-${part()}`;
}

function findUser(store: AnyRecord, userId: string): AnyRecord | undefined {
  return store.users.find((u: AnyRecord) => u.id === userId);
}

function getPlan(store: AnyRecord, planId: string): AnyRecord | undefined {
  return store.plans.find((p: AnyRecord) => p.id === planId);
}

function addMessage(store: AnyRecord, fromUserId: string, toUserId: string | null, text: string, kind = "dm", payload: AnyRecord = {}) {
  const from = store.users.find((u: AnyRecord) => u.id === fromUserId) || { name: "KiwiFarm" };
  const to = store.users.find((u: AnyRecord) => u.id === toUserId) || null;
  store.messages.push({ id: id("msg"), fromUserId, fromName: from.name, toUserId, toName: to?.name || "", text, kind, payload, read: false, createdAt: nowIso() });
}

function pixQrDataUrl(text: string) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="280" height="280"><rect width="100%" height="100%" fill="white"/><text x="50%" y="45%" text-anchor="middle" font-family="Arial" font-size="18" fill="black">PIX</text><text x="50%" y="56%" text-anchor="middle" font-family="Arial" font-size="12" fill="black">${String(text || "").slice(0, 28)}</text></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

const methods: AnyRecord = {
  bootstrap() {
    const store = getStore();
    return { plans: store.plans.map((p: AnyRecord) => planWithStock(store, p)), stats: {}, settings: store.settings };
  },

  login(identifier: string, password: string) {
    const store = getStore();
    const ident = String(identifier || "").trim().toLowerCase();
    const user = store.users.find((u: AnyRecord) => (u.email.toLowerCase() === ident || u.username.toLowerCase() === ident) && u.password === password);
    if (!user) return { ok: false, message: "Login ou senha invalidos." };
    return { ok: true, user: publicUser(user), dashboard: dashboardFor(store, user) };
  },

  register(name: string, email: string, username: string, password: string, inviteCode = "") {
    const store = getStore();
    const cleanEmail = String(email || "").trim().toLowerCase();
    const cleanUsername = String(username || "").trim().toLowerCase();
    if (!name || !cleanEmail.includes("@") || cleanUsername.length < 3 || String(password || "").length < 8) return { ok: false, message: "Preencha nome, email, usuario e senha com pelo menos 8 caracteres." };
    if (store.users.some((u: AnyRecord) => u.email === cleanEmail || u.username === cleanUsername)) return { ok: false, message: "Email ou usuario ja cadastrado." };
    const code = String(inviteCode || "").split("?")[0].split("/").filter(Boolean).pop()?.toLowerCase() || "";
    const inviter = store.users.find((u: AnyRecord) => [u.inviteCode, u.resellerInviteCode, u.promoterInviteCode].map((x: string) => String(x || "").toLowerCase()).includes(code));
    const trialEndsAt = addMs(5 * 60 * 60 * 1000);
    const user = { id: id("user"), email: cleanEmail, username: cleanUsername, name, role: "free", roles: ["free"], password, createdAt: nowIso(), trialEndsAt, accessEndsAt: trialEndsAt, planStatus: "trial", credits: 0, inviteCode: `${cleanUsername}-${Math.random().toString(16).slice(2, 6)}`, profile: {}, referredBy: inviter?.id || null, referredByRole: inviter?.role || null };
    store.users.push(user);
    if (inviter) addMessage(store, user.id, inviter.id, `${name} criou conta pelo seu convite.`, "referral");
    return { ok: true, user: publicUser(user), dashboard: dashboardFor(store, user) };
  },

  dashboard(userId: string) {
    const store = getStore();
    const user = findUser(store, userId);
    if (!user) return { ok: false, message: "Usuario nao encontrado." };
    return { ok: true, user: publicUser(user), dashboard: dashboardFor(store, user) };
  },

  kiwify_login() {
    return { ok: false, message: "No Vercel nao da para abrir o Chrome local. Use o app desktop para conectar a Kiwify." };
  },

  run_factory(userId: string, niche: string) {
    const store = getStore();
    const user = findUser(store, userId);
    if (!user) return { ok: false, message: "Usuario nao encontrado." };
    if (!isAdmin(user) && !accessStatus(user).active) return { ok: false, expired: true, message: "Seu teste acabou. Adquira um plano ou ative uma key." };
    const price = [1990, 2490, 2990, 3990][Math.floor(Math.random() * 4)];
    const sales = [60, 100, 150][Math.floor(Math.random() * 3)];
    const name = `${String(niche || "Produto digital").split("|")[0].trim()} ${["Express", "Playbook", "Lab"][Math.floor(Math.random() * 3)]}`;
    store.products.push({ id: id("prod"), ownerId: userId, name, status: "prepared", priceCents: price, estimatedRevenueCents: price * sales, createdAt: nowIso() });
    return { ok: true, message: "Produto preparado no Vercel. Para publicar na Kiwify automaticamente, use o app desktop." };
  },

  open_products_folder() {
    return { ok: false, message: "Funcao local do desktop. No Vercel, veja produtos no dashboard." };
  },

  generate_keys(adminId: string, payload: AnyRecord) {
    const store = getStore();
    const admin = findUser(store, adminId);
    if (!isAdmin(admin)) return { ok: false, message: "Apenas admin." };
    const plan = getPlan(store, payload.planId) || store.plans[0];
    const count = Math.max(1, Math.min(100, Number(payload.count || 1)));
    const keys = Array.from({ length: count }, () => ({ id: id("key"), code: makeKey(payload.prefix || "OMEGA-"), planId: plan.id, planName: plan.name, durationDays: Number(payload.durationDays || plan.durationDays), status: payload.stock === false ? "active" : "stock", assignedTo: null, deliveredTo: null, deviceId: null, createdAt: nowIso(), createdBy: adminId }));
    store.keys.push(...keys);
    return { ok: true, keys, dashboard: dashboardFor(store, admin) };
  },

  search_keys(query: string) {
    const store = getStore();
    const q = String(query || "").toLowerCase();
    const keys = store.keys.filter((k: AnyRecord) => !q || k.code.toLowerCase().includes(q) || k.status.toLowerCase().includes(q) || String(owner(store, k.assignedTo || k.deliveredTo || k.resellerId).email || "").toLowerCase().includes(q)).slice(-120).map((k: AnyRecord) => ({ ...k, owner: owner(store, k.assignedTo || k.deliveredTo || k.resellerId) })).reverse();
    return { ok: true, keys };
  },

  update_key_status(keyId: string, action: string) {
    const store = getStore();
    const key = store.keys.find((k: AnyRecord) => k.id === keyId);
    if (!key) return { ok: false, message: "Key nao encontrada." };
    if (action === "reset") Object.assign(key, { status: "stock", assignedTo: null, deliveredTo: null, deviceId: null, activatedAt: null, expiresAt: null });
    if (action === "cancel") key.status = "cancelled";
    if (action === "pause") key.status = "paused";
    if (action === "activate") key.status = "active";
    return { ok: true, key };
  },

  redeem_key(userId: string, code: string, deviceId: string) {
    const store = getStore();
    const user = findUser(store, userId);
    const key = store.keys.find((k: AnyRecord) => String(k.code).toLowerCase() === String(code || "").trim().toLowerCase());
    if (!user || !key) return { ok: false, message: "Key invalida." };
    if (["cancelled", "paused", "used"].includes(key.status)) return { ok: false, message: `Key esta ${key.status}.` };
    const expiresAt = addMs(Number(key.durationDays || 30) * 24 * 60 * 60 * 1000);
    Object.assign(key, { status: "used", assignedTo: user.id, deliveredTo: user.id, deviceId, activatedAt: nowIso(), expiresAt });
    user.accessEndsAt = expiresAt;
    user.planStatus = "paid";
    user.roles = Array.from(new Set([...(user.roles || []), key.durationDays > 365 ? "permanent" : "monthly"]));
    user.role = key.durationDays > 365 ? "permanent" : "monthly";
    return { ok: true, message: "Key ativada.", user: publicUser(user), dashboard: dashboardFor(store, user) };
  },

  save_settings(settings: AnyRecord) {
    const store = getStore();
    store.settings = { ...store.settings, ...settings, siteInviteBase: settings.siteInviteBase || "https://kiwifarm.mobile" };
    return { ok: true, settings: store.settings };
  },

  search_users(query: string) {
    const store = getStore();
    const q = String(query || "").toLowerCase();
    return { ok: true, users: store.users.filter((u: AnyRecord) => !q || u.email.toLowerCase().includes(q) || u.username.toLowerCase().includes(q) || u.name.toLowerCase().includes(q)).map(publicUser) };
  },

  set_user_access(userId: string, hours: number, days: number, role = "") {
    const store = getStore();
    const user = findUser(store, userId);
    const admin = store.users[0];
    if (!user) return { ok: false, message: "Usuario nao encontrado." };
    user.accessEndsAt = addMs((Number(hours || 0) * 60 * 60 + Number(days || 0) * 24 * 60 * 60) * 1000);
    if (role) {
      user.roles = Array.from(new Set([...(user.roles || []), role]));
      user.role = role;
    }
    return { ok: true, user: publicUser(user), dashboard: dashboardFor(store, admin) };
  },

  expire_user(userId: string) {
    const store = getStore();
    const user = findUser(store, userId);
    if (!user) return { ok: false, message: "Usuario nao encontrado." };
    user.accessEndsAt = new Date(Date.now() - 1000).toISOString();
    return { ok: true, user: publicUser(user), dashboard: dashboardFor(store, store.users[0]) };
  },

  save_plan(plan: AnyRecord) {
    const store = getStore();
    const clean = { ...plan, id: plan.id || id("plan"), priceCents: Number(plan.priceCents || 0), durationDays: Number(plan.durationDays || 1), active: plan.active !== false, stockTarget: Number(plan.stockTarget || 0), keyCostCredits: Number(plan.keyCostCredits || 1), quotas: { dailyProducts: Number(plan.dailyProducts || plan.quotas?.dailyProducts || 0), dailyVideos: Number(plan.dailyVideos || plan.quotas?.dailyVideos || 0) }, resellerEnabled: true };
    store.plans = store.plans.filter((p: AnyRecord) => p.id !== clean.id).concat(clean);
    return { ok: true, plans: store.plans.map((p: AnyRecord) => planWithStock(store, p)) };
  },

  create_payment_request(userId: string, payload: AnyRecord) {
    const store = getStore();
    const user = findUser(store, userId);
    if (!user) return { ok: false, message: "Usuario nao encontrado." };
    const plan = payload.type === "plan" ? getPlan(store, payload.planId) : null;
    const credits = Number(payload.credits || 0);
    const amountCents = plan ? Number(plan.priceCents) : credits * Number(store.settings.creditPriceCents || 1000);
    const payment = { id: id("pay"), userId, userName: user.name, userEmail: user.email, type: payload.type || "plan", planId: plan?.id || null, planName: plan?.name || "", credits, amountCents, pixKey: store.settings.pixKey, pixQrDataUrl: pixQrDataUrl(store.settings.pixKey), status: "pending_payment", expiresAt: addMs(30 * 60 * 1000), createdAt: nowIso() };
    store.payments.push(payment);
    return { ok: true, payment, dashboard: dashboardFor(store, user) };
  },

  mark_paid(userId: string, paymentId: string) {
    const store = getStore();
    const user = findUser(store, userId);
    const payment = store.payments.find((p: AnyRecord) => p.id === paymentId && p.userId === userId);
    if (!user || !payment) return { ok: false, message: "Pagamento nao encontrado." };
    payment.status = "waiting_owner";
    addMessage(store, userId, "admin-primary", `${user.name} informou pagamento: ${payment.planName || `${payment.credits} creditos`}.`, "payment", { paymentId });
    return { ok: true, payment, dashboard: dashboardFor(store, user) };
  },

  review_payment(adminId: string, paymentId: string, approve: boolean) {
    const store = getStore();
    const admin = findUser(store, adminId);
    if (!isAdmin(admin)) return { ok: false, message: "Apenas admin." };
    const payment = store.payments.find((p: AnyRecord) => p.id === paymentId);
    if (!payment) return { ok: false, message: "Pagamento nao encontrado." };
    const buyer = findUser(store, payment.userId);
    payment.status = approve ? "confirmed" : "refused";
    if (approve && buyer) {
      if (payment.type === "credits") buyer.credits = Number(buyer.credits || 0) + Number(payment.credits || 0);
      if (payment.type === "plan") {
        const plan = getPlan(store, payment.planId);
        buyer.accessEndsAt = addMs(Number(plan?.durationDays || 30) * 24 * 60 * 60 * 1000);
        buyer.planStatus = "paid";
        buyer.roles = Array.from(new Set([...(buyer.roles || []), ...(plan?.grantRoles || ["monthly"])]));
        buyer.role = buyer.roles.includes("permanent") ? "permanent" : "monthly";
      }
    }
    return { ok: true, payment, dashboard: dashboardFor(store, admin) };
  },

  send_dm(fromUserId: string, toUserId: string, text: string) {
    const store = getStore();
    const sender = findUser(store, fromUserId);
    const target = findUser(store, toUserId) || store.users.find(isAdmin);
    if (!sender || !target) return { ok: false, message: "Usuario nao encontrado." };
    addMessage(store, sender.id, target.id, String(text || "").slice(0, 1200), "dm");
    return { ok: true, dashboard: dashboardFor(store, sender) };
  },

  mark_thread_read(userId: string, peerId: string) {
    const store = getStore();
    const user = findUser(store, userId);
    if (!user) return { ok: false, message: "Usuario nao encontrado." };
    store.messages.forEach((m: AnyRecord) => {
      if (m.toUserId === userId && m.fromUserId === peerId) m.read = true;
    });
    return { ok: true, dashboard: dashboardFor(store, user) };
  },

  apply_reseller(userId: string, fields: AnyRecord) {
    return applyRole("reseller", userId, fields);
  },

  apply_promoter(userId: string, fields: AnyRecord) {
    return applyRole("promoter", userId, fields);
  },

  reseller_buy_credits(userId: string, credits: number) {
    return methods.create_payment_request(userId, { type: "credits", credits });
  },

  reseller_generate_key(userId: string, planId: string, prefix = "OMEGA-") {
    const store = getStore();
    const user = findUser(store, userId);
    const plan = getPlan(store, planId);
    if (!user || !plan) return { ok: false, message: "Usuario ou plano nao encontrado." };
    if (!hasRole(user, "reseller")) return { ok: false, message: "Apenas revendedores aprovados podem gerar keys." };
    const cost = Number(plan.keyCostCredits || 1);
    if (Number(user.credits || 0) < cost) return { ok: false, message: "Creditos insuficientes." };
    user.credits = Number(user.credits || 0) - cost;
    const key = { id: id("key"), code: makeKey(prefix), planId: plan.id, planName: plan.name, durationDays: Number(plan.durationDays || 30), status: "active", resellerId: userId, source: "reseller", creditCost: cost, createdAt: nowIso() };
    store.keys.push(key);
    addMessage(store, "admin-primary", userId, `Key gerada para revenda: ${key.code}.`, "key", { code: key.code });
    return { ok: true, key, dashboard: dashboardFor(store, user) };
  },

  social_login(platform: string) {
    return { ok: false, message: `Login ${platform} deve ser feito pelo app desktop/local.` };
  },

  connect_social(userId: string, platform: string, handle: string) {
    const store = getStore();
    const user = findUser(store, userId);
    if (!user) return { ok: false, message: "Usuario nao encontrado." };
    store.socialConnections = store.socialConnections.filter((s: AnyRecord) => !(s.userId === userId && s.platform === platform));
    store.socialConnections.push({ id: id("social"), userId, platform, handle, status: "connected", createdAt: nowIso() });
    return { ok: true, dashboard: dashboardFor(store, user) };
  }
};

function applyRole(type: "reseller" | "promoter", userId: string, fields: AnyRecord) {
  const store = getStore();
  const user = findUser(store, userId);
  if (!user) return { ok: false, message: "Usuario nao encontrado." };
  const app = { id: id("app"), type, userId, userName: user.name, userEmail: user.email, status: "pending", fields, createdAt: nowIso() };
  store.applications.push(app);
  addMessage(store, userId, "admin-primary", `Nova inscricao de ${type}: ${user.name}.`, "application", { applicationId: app.id });
  return { ok: true, application: app, dashboard: dashboardFor(store, user) };
}

export async function POST(request: Request) {
  try {
    const payload = await request.json();
    const methodName = String(payload.method || "");
    const args = Array.isArray(payload.args) ? payload.args : [];
    if (!methods[methodName]) return Response.json({ ok: false, message: "Metodo nao permitido." }, { status: 403 });
    return Response.json(methods[methodName](...args));
  } catch (error: any) {
    return Response.json({ ok: false, message: error?.message || "Erro interno." }, { status: 500 });
  }
}

export async function OPTIONS() {
  return new Response(null, { status: 204 });
}
