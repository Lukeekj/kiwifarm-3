import type { ReactNode } from "react";
import type { Metadata, Viewport } from "next";

export const metadata: Metadata = {
  title: "KiwiFarm Mobile",
  applicationName: "KiwiFarm",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "KiwiFarm",
    statusBarStyle: "black-translucent"
  }
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#7c3aed"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body style={{ margin: 0, background: "#07070d" }}>{children}</body>
    </html>
  );
}
