export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({ ok: true, service: "KiwiFarm Next", version: "1.0.0" });
}
