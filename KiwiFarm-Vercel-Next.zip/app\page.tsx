export default function Page() {
  return (
    <main style={{ width: "100vw", minHeight: "100vh", background: "#07070d" }}>
      <iframe
        title="KiwiFarm Mobile"
        src="/mobile.html"
        style={{
          width: "100vw",
          height: "100vh",
          border: 0,
          display: "block",
          background: "#07070d"
        }}
      />
    </main>
  );
}
